rm -rf robotQQServer  &&	g++  main.cpp netComm.cpp stroeData.cpp -o robotQQServer -lpthread
